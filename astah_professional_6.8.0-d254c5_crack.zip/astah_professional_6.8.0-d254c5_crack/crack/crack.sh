#! /bin/bash

cd ..

for libfile in `ls lib/*.jar -a $1`  
do
    if [ x"$libfile" != x"." -a x"$libfile" != x".." ];then
        if [ -f "$libfile" ];then
            export CLASSPATH=$CLASSPATH:$libfile 
        fi  
    fi  
done

for libfile in `ls crack/*.jar -a $1`  
do  
    if [ x"$libfile" != x"." -a x"$libfile" != x".." ];then  
        if [ -f "$libfile" ];then
            export CLASSPATH=$CLASSPATH:$libfile 
        fi  
    fi  
done

export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/jre/lib/jfxrt.jar

echo $CLASSPATH
ajc -Xmx1024m -injars astah-pro.jar -injars $ASPECTJ_HOME/lib/aspectjrt.jar -sourceroots crack -outjar astah-pro_crack.jar
